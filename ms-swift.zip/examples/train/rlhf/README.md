# TIPS

Multi-modal models' RLHF are also supported! Check the multimodal folder for details.
