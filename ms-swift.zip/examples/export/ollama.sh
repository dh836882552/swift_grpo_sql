swift export \
    --model Qwen/Qwen2.5-1.5B-Instruct \
    --to_ollama true \
    --output_dir Qwen2.5-1.5B-Instruct-ollama
