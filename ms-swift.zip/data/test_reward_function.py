import asyncio
import re
from typing import List

import json

from swift.plugin import ORM, orms
from swift.utils import get_logger


logger = get_logger()

class SqlFormat(ORM):

    def __call__(self, completions, **kwargs) -> List[float]:
        """Reward function that checks if the completion has a specific format."""
        pattern = r'^<think>.*?</think>\s*<answer>.*?</answer>(?![\s\S])'
        matches = [re.match(pattern, content, re.DOTALL | re.MULTILINE) for content in completions]
        return [1.0 if match else 0.0 for match in matches]


class SqlAccuracy(ORM):

    def __call__(self, completions, solution, **kwargs) -> List[float]:
        """
        Reward function that checks if the completion is correct.
        Args:
            completions (list[str]): Generated outputs
            solution (list[str]): Ground Truths.
        Returns:
            list[float]: Reward scores
        """
        rewards = []
        from math_verify import parse, verify
        for content, sol in zip(completions, solution):
            reward = 0.0
            # If symbolic verification failed, try string matching
            try:
                # Extract answer from solution if it has think/answer tags
                sol_match = re.search(r'<answer>(.*?)</answer>', sol)
                ground_truth = sol_match.group(1).strip() if sol_match else sol.strip()

                # Extract answer from content if it has think/answer tags
                content_match = re.search(r'<answer>(.*?)</answer>', content)
                student_answer = content_match.group(1).strip() if content_match else content.strip()

                # Compare the extracted answers
                if student_answer == ground_truth:
                    reward = 1.0
            except Exception:
                pass  # Keep reward as 0.0 if both methods fail
            rewards.append(reward)
        return rewards


class SqlExecution(ORM):
    import mysql.connector
    import re
    def __call__(self, completions, **kwargs) -> List[float]:
        """
        Reward function that checks if the completion is correct.
        Args:
            completions (list[str]): Generated outputs
        Returns:
            list[float]: Reward scores
        """
        rewards = []
        for content in completions:
            reward = 0.0
            try:
                # Extract answer from content if it has think/answer tags
                content_match = re.search(r'<answer>(.*?)</answer>', content)
                student_answer = content_match.group(1).strip() if content_match else content.strip()

                # 创建数据库连接
                db_connection = mysql.connector.connect(
                    host="localhost",
                    user="root",
                    password="1234",
                    database="test01"
                )
                cursor = db_connection.cursor()
                cursor.execute(student_answer)
                db_connection.commit()
                db_connection.close()

                reward = 1.0  # 执行成功
            except Exception as e:
                print(f"SQL Execution Error: {e}")  # 记录错误
            rewards.append(reward)
        return rewards
test_completions = [
    "<think>Let's analyze the query...</think> <answer>SELECT * FROM users;</answer>",
    "<think>First, I consider the table schema...</think> <answer>DROP TABLE students;</answer>",
    "SELECT * FROM orders;"
]

test_solutions = [
    "<think>We analyze the query...</think> <answer>SELECT * FROM users;</answer>",
    "<think>We should consider constraints...</think> <answer>DELETE FROM students;</answer>",
    "SELECT * FROM orders;"
]

sql_format = SqlFormat()
format_rewards = sql_format(test_completions)
print("SqlFormat Rewards:", format_rewards)

sql_accuracy = SqlAccuracy()
accuracy_rewards = sql_accuracy(test_completions, test_solutions)
print("SqlAccuracy Rewards:", accuracy_rewards)

sql_execution = SqlExecution()
execution_rewards = sql_execution(test_completions)
print("SqlExecution Rewards:", execution_rewards)
