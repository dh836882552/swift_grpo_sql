import subprocess
import os

def run_rlhf_training():
    command = [
        "swift", "rlhf", # 调用 swift 工具的 rlhf 模块
        "--rlhf_type", "grpo", # 指定 RLHF 的类型，这里使用 grpo
        "--model", "Qwen/Qwen2.5-0.5B-Instruct", #Qwen/Qwen2.5-7B-Instruct
        "--external_plugins", "D:\\softfile\\ms-swift\\examples\\train\\grpo\\plugin\\plugin.py",
        "--reward_funcs", "external_sql_format",  # "external_sql_format", "external_sql_accuracy", "external_sql_execution",
        "--train_type", "lora",
        "--lora_rank", "8", # LoRA 的秩参数，影响低秩分解的维度
        "--lora_alpha", "32", # LoRA 的 alpha 缩放因子
        "--target_modules", "all-linear",  # 指定需要进行 LoRA 调优的模块，此处为所有线性层
        "--torch_dtype", "bfloat16", # 指定训练时使用的数值类型，这里使用 bfloat16，降低内存占用
        "--dataset", "D:\\softfile\\ms-swift\\data\\mydata.json",
        "--max_completion_length", "1024", # 采样生成文本的最大长度，超过此长度的生成结果将被截断
        "--num_train_epochs", "1",
        "--per_device_train_batch_size", "4",  # 每个设备（如 CPU）上训练时的 batch size，此处为 4
        "--per_device_eval_batch_size", "4", # 每个设备上评估时的 batch size
        "--learning_rate", "1e-5",  # 学习率设置，指定优化器的步长
        "--gradient_accumulation_steps", "4",   # 梯度累积步数，累积 4 个 batch 后再更新梯度，有助于降低内存占用
        "--eval_steps", "100", # 每 100 步进行一次评估
        "--save_steps", "100", # 每 100 步保存一次模型检查点
        "--save_total_limit", "2", # 最多保留 2 个检查点，多余的将自动删除
        "--logging_steps", "5",
        "--max_length", "2048", # 模型输入的最大长度（token 数），超过此长度的输入会被截断
        "--output_dir", "output",
        "--warmup_ratio", "0.05", # 学习率预热比例，此处为 5%
        "--dataloader_num_workers", "0",  # DataLoader 使用的子进程数，此处设置为 0，避免多进程序列化问题（特别是 CPU 训练时）
        "--dataset_num_proc", "2", # 加载数据集时使用的进程数，此处为 2
        "--num_generations", "4", # 每个 prompt 生成的样本数量，此处为 4，要求全局 batch size 能被此数整除
        "--temperature", "0.0",  # 采样温度，0.0 表示确定性采样；temperature 越大，则新的概率分布越均匀，随机性也就越大，越容易生成一些意想不到的词。
        "--system", "D:\\softfile\\ms-swift\\examples\\train\\grpo\\prompt.txt", # 指定系统 prompt 文件的路径，用于训练时提供上下文提示
        "--log_completions", "true" #完整日志记录
    ]

    # 设置环境变量，强制使用 CPU
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = "-1"

    try:
        subprocess.run(command, env=env, check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")

if __name__ == "__main__":

    run_rlhf_training()




