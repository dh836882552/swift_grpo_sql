# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.llm import rlhf_main

if __name__ == '__main__':
    rlhf_main()
