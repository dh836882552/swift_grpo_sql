# Copyright (c) Alibaba, Inc. and its affiliates.
from .eval import SwiftEval, eval_main
